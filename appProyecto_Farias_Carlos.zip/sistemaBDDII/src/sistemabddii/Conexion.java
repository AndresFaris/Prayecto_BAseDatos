/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemabddii;
import java.sql.*;

/**
 *
 * @author Carlos
 */
public class Conexion {
    //url es la ruta de conexion
    static String url="jdbc:oracle:thin:@localhost:1521:basedatos";
    // el usuario y contraseña para la basse de datos
    static String user="system";
    static String pass="basedatos";    
    Connection CONEXION;
    // se crea la funcio 
    public Conexion(){
    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
    }
    catch(ClassNotFoundException ex){
    System.out.println(ex.getMessage());
    }
    try {
        // laamamos al driver para que ejecute la conexion con los parametros indicados
    CONEXION= DriverManager.getConnection(url,user,pass);
    }
    catch(Exception e){
        // manejo de errores
    System.out.println("Error de conexion del driver"+ e.getMessage());
    }
  
    }
    public Connection getCONEXION() {
        return CONEXION;
    }

    
    
}
