/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package formulario;

import static formulario.formulario.codigo_formulario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import sistemabddii.Conexion;
import sistemabddii.GenerarCodigos;
import sistemabddii.panel;

/**
 *
 * @author Carlos
 */
public class Opcionesform {
    
    static Conexion cc = new Conexion();
    static Connection cn = cc.getCONEXION();
    static PreparedStatement ps;
    public static int REGISTRAR_FORMULARIO(formularioCod uc){
        int rsu=0;
        String sql = formularioCod.REGISTRAR_FORM;
        try {
            ps = cn.prepareStatement(sql);
            ps.setString(1, uc.getPrimarykey());
            ps.setString(2, uc.getNombreoficina());
            ps.setString(3, uc.getProvinciaoficina());
            ps.setString(4, uc.getCantonoficina());
            ps.setString(5, uc.getParroquiaoficina());
            ps.setString(6, uc.getFechains());
            ps.setString(7, uc.getActains());
            
            rsu = ps.executeUpdate();
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        System.out.println(sql);
        return rsu;
    }
     public static int REGISTRAR_FETAL(formularioCod uc){
        int rsu=0;
        String sql = formularioCod.ACTUALIZAR_DATOSFETAL;
        try {
            ps = cn.prepareStatement(sql);
            ps.setString(1, uc.getSexo());
            ps.setString(2, uc.getSemanasgestacion());
            ps.setString(3, uc.getFechaocirrencia());
            ps.setString(4, uc.getProductoembarazo());
            ps.setString(5, uc.getAsistidopo());
            ps.setString(6, uc.getLugarocurrencia());
            ps.setString(7, uc.getNombreestablecimiento());
            ps.setString(8, uc.getProvinciafeta());
            ps.setString(9, uc.getCantonfetal());
            ps.setString(10, uc.getParroquifetal());
            ps.setString(11, uc.getLocalidadfetal());
            ps.setString(12, uc.getCausafetal());
            ps.setString(13, uc.getPrimarykey());
            
            rsu = ps.executeUpdate();
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        System.out.println(sql);
        return rsu;
    } public static int REGISTRAR_MADRE(formularioCod uc){
        int rsu=0;
        String sql = formularioCod.ACTUALIZAR_DATOSMADRE;
        try {
            ps = cn.prepareStatement(sql);
            ps.setString(1, uc.getNombresmadre());
            ps.setString(2, uc.getFechamadre());
            ps.setString(3, uc.getNacidosvivos());
            ps.setString(4, uc.getNacionalidadmadre());
            ps.setString(5, uc.getEdad());
            ps.setString(6, uc.getNacidosmuertos());
            ps.setString(7, uc.getIdmadre());
            ps.setString(8, uc.getHijostiene());
            ps.setString(9, uc.getControlesembarazo());
            ps.setString(10, uc.getAutoidentifica());
            ps.setString(11, uc.getEstadocivil());
            ps.setString(12, uc.getLeeescribe());
            ps.setString(13, uc.getNivelinstruccion());
            ps.setString(14, uc.getProvinciamadre());
            ps.setString(15, uc.getCantonmadre());
            ps.setString(16, uc.getParroquimadre());
            ps.setString(17, uc.getLocalidadmadre());
            ps.setString(18, uc.getDireccionmadre());
            ps.setString(19, uc.getPrimarykey());
            
            rsu = ps.executeUpdate();
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        System.out.println(sql);
        return rsu;
    }
   public static int REGISTRAR_INFOGENERAL(formularioCod uc){
        int rsu=0;
        String sql = formularioCod.ACTUALIZAR_INFO;
        try {
            ps = cn.prepareStatement(sql);
            ps.setString(1, uc.getNombresinfo());
            ps.setString(2, uc.getCedulainfo());
            ps.setString(3, uc.getTelefonoinfo());
            ps.setString(4, uc.getObservacionesinfo());
            ps.setString(5, uc.getPrimarykey());
                       
            rsu = ps.executeUpdate();
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        System.out.println(sql);
        return rsu;
    }
    
    
    
    public static void extraerID() {
        int b;
        int cont = 1;
        String num = "";
        String c = "";
        String SQL = "SELECT MAX(COD_FORM) FROM FORMULARIO";

        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(SQL);
            while (rs.next()) {
                c = rs.getString(1);
            }
            if (c == null) {
                formulario.codigo_formulario.setText("FM0001");
            } else {
                char r1 = c.charAt(2);
                char r2 = c.charAt(3);
                char r3 = c.charAt(4);
                char r4 = c.charAt(5);
                String a = "";
                a = "" + r1 + r2 + r3 + r4;
                b = Integer.parseInt(a);
                GenerarCodigos gen = new GenerarCodigos();
                gen.generar(b);
                formulario.codigo_formulario.setText("FM" + gen.serie());
            }

        } catch (SQLException ex) {
            Logger.getLogger(Opcionesform.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public static void listarRegistros() {
        DefaultTableModel modelo = (DefaultTableModel) panel.tablaregistros.getModel();

        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }
        String sql = "SELECT * FROM INGRESADOS ";
        
        String datos[] = new String[5];
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                datos[0] = rs.getString("OFICINA");
                datos[1] = rs.getString("FECHA_INSCRIPCION");
                datos[2] = rs.getString("CODIGO");
                datos[3] = rs.getString("MADRE");
                datos[4] = rs.getString("HIJOS_NACIDOS_MUERTOS");
                
                modelo.addRow(datos);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Opcionesform.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    
}
