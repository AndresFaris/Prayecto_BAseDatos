/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package formulario;

/**
 *
 * @author Carlos
 */
public class formularioCod {
    public static String REGISTRAR_FORM="insert into FORMULARIO(COD_FORM, OF_REG_CIVIL, PROVINCIA, CANTON, PARROQUIA, FECHA_INS,ACTA_INS)"
            + "values (?,?,?,?,?,?,?) ";
    
    public static String ACTUALIZAR_DATOSFETAL="UPDATE DATOS_FETAL set "
            + "SEXO=?, "
            + "SEM_GEST=?, "
            + "FECHA_OCURRENCIA=?, "
            + "PRODUCTO_EMBARAZO=?, "
            + "ASISTIDO_POR=?, "
            + "LUGAR_OCURRENCCIA=?, "
            + "NOM_ESTABLECIMIENTO=?, "
            + "PROVINCIA=?, "
            + "CANTON=?, "
            + "PARROQUIA=?, "
            + "LOCALIDAD=?, "
            + "CAUSA=? WHERE COD_FORM=?";
    public static String ACTUALIZAR_DATOSMADRE="UPDATE DATOS_MADRE set "
            + "NOMBRES_APELLIDOS=?, "
            + "FECHA_NACIMIENTO=?, "
            + "NACIDOS_VIVOS_MUERTOS=?, "
            + "NACIONALIDAD=?, "
            + "EDAD=?,  "
            + "NACIDOS_MUERTOS=?, "
            + "ID_PASAPORTE=?, "
            + "HIJOS_TIENE=?, "
            + "CONTROLES_PARENTALES=?, "
            + "AUTOIDENTIFICACION=?, "
            + "ESTADO_CIVIL=?, "
            + "LEER_ESCRIBIR=?, "
            + "NIVEL_INSTRUCCION=?, "
            + "PROVINCIA=?, "
            + "CANTON=?, "
            + "PARROQUIA=?, "
            + "LOCALIDAD=?, "
            + "DIRECCION=? WHERE COD_FORM=? ";
    public static String ACTUALIZAR_INFO="UPDATE INFO_GENERAL set "
            + "NOMBRE_APELLIDOS=?, "
            + "CEDULA=?, "
            + "TELEFONO=?, "
            + "OBSERVACIONES=? WHERE COD_FORM=? ";
    
    public static String LISTAR_RG = "SELECT * FROM INGRESADOS ORDER BY COD_FORM";
    
    public String primarykey;
    public String nombreoficina;
    public String provinciaoficina;
    public String cantonoficina;
    public String parroquiaoficina;
    public String fechains;
    public String actains;
    
    public String sexo;
    public String semanasgestacion;
    public String fechaocirrencia;
    public String productoembarazo;
    public String asistidopo;
    public String lugarocurrencia;
    public String nombreestablecimiento;
    public String provinciafeta;
    public String cantonfetal;
    public String parroquifetal;
    public String localidadfetal;
    public String causafetal;
    
    public String nombresmadre;
    public String fechamadre;
    public String nacidosvivos;
    public String nacionalidadmadre;
    public String edad;
    public String nacidosmuertos;
    public String idmadre;
    public String hijostiene;
    public String controlesembarazo;
    public String autoidentifica;
    public String estadocivil;
    public String leeescribe;
    public String nivelinstruccion;
    public String provinciamadre;
    public String cantonmadre;
    public String parroquimadre;
    public String localidadmadre;
    public String direccionmadre;
    
    public String nombresinfo;
    public String cedulainfo;
    public String telefonoinfo;
    public String observacionesinfo;
    
    public formularioCod(){
    
    }

    public String getNombresinfo() {
        return nombresinfo;
    }

    public void setNombresinfo(String nombresinfo) {
        this.nombresinfo = nombresinfo;
    }

    public String getCedulainfo() {
        return cedulainfo;
    }

    public void setCedulainfo(String cedulainfo) {
        this.cedulainfo = cedulainfo;
    }

    public String getTelefonoinfo() {
        return telefonoinfo;
    }

    public void setTelefonoinfo(String telefonoinfo) {
        this.telefonoinfo = telefonoinfo;
    }

    public String getObservacionesinfo() {
        return observacionesinfo;
    }

    public void setObservacionesinfo(String observacionesinfo) {
        this.observacionesinfo = observacionesinfo;
    }
    
    public String getNombresmadre() {
        return nombresmadre;
    }

    public void setNombresmadre(String nombresmadre) {
        this.nombresmadre = nombresmadre;
    }

    public String getFechamadre() {
        return fechamadre;
    }

    public void setFechamadre(String fechamadre) {
        this.fechamadre = fechamadre;
    }

    public String getNacidosvivos() {
        return nacidosvivos;
    }

    public void setNacidosvivos(String nacidosvivos) {
        this.nacidosvivos = nacidosvivos;
    }

    public String getNacionalidadmadre() {
        return nacionalidadmadre;
    }

    public void setNacionalidadmadre(String nacionalidadmadre) {
        this.nacionalidadmadre = nacionalidadmadre;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getNacidosmuertos() {
        return nacidosmuertos;
    }

    public void setNacidosmuertos(String nacidosmuertos) {
        this.nacidosmuertos = nacidosmuertos;
    }

    public String getIdmadre() {
        return idmadre;
    }

    public void setIdmadre(String idmadre) {
        this.idmadre = idmadre;
    }

    public String getHijostiene() {
        return hijostiene;
    }

    public void setHijostiene(String hijostiene) {
        this.hijostiene = hijostiene;
    }

    public String getControlesembarazo() {
        return controlesembarazo;
    }

    public void setControlesembarazo(String controlesembarazo) {
        this.controlesembarazo = controlesembarazo;
    }

    public String getAutoidentifica() {
        return autoidentifica;
    }

    public void setAutoidentifica(String autoidentifica) {
        this.autoidentifica = autoidentifica;
    }

    public String getEstadocivil() {
        return estadocivil;
    }

    public void setEstadocivil(String estadocivil) {
        this.estadocivil = estadocivil;
    }

    public String getLeeescribe() {
        return leeescribe;
    }

    public void setLeeescribe(String leeescribe) {
        this.leeescribe = leeescribe;
    }

    public String getNivelinstruccion() {
        return nivelinstruccion;
    }

    public void setNivelinstruccion(String nivelinstruccion) {
        this.nivelinstruccion = nivelinstruccion;
    }

    public String getProvinciamadre() {
        return provinciamadre;
    }

    public void setProvinciamadre(String provinciamadre) {
        this.provinciamadre = provinciamadre;
    }

    public String getCantonmadre() {
        return cantonmadre;
    }

    public void setCantonmadre(String cantonmadre) {
        this.cantonmadre = cantonmadre;
    }

    public String getParroquimadre() {
        return parroquimadre;
    }

    public void setParroquimadre(String parroquimadre) {
        this.parroquimadre = parroquimadre;
    }

    public String getLocalidadmadre() {
        return localidadmadre;
    }

    public void setLocalidadmadre(String localidadmadre) {
        this.localidadmadre = localidadmadre;
    }

    public String getDireccionmadre() {
        return direccionmadre;
    }

    public void setDireccionmadre(String direccionmadre) {
        this.direccionmadre = direccionmadre;
    }
    

    public String getSemanasgestacion() {
        return semanasgestacion;
    }

    public void setSemanasgestacion(String semanasgestacion) {
        this.semanasgestacion = semanasgestacion;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getFechaocirrencia() {
        return fechaocirrencia;
    }

    public void setFechaocirrencia(String fechaocirrencia) {
        this.fechaocirrencia = fechaocirrencia;
    }

    public String getProductoembarazo() {
        return productoembarazo;
    }

    public void setProductoembarazo(String productoembarazo) {
        this.productoembarazo = productoembarazo;
    }

    public String getAsistidopo() {
        return asistidopo;
    }

    public void setAsistidopo(String asistidopo) {
        this.asistidopo = asistidopo;
    }

    public String getLugarocurrencia() {
        return lugarocurrencia;
    }

    public void setLugarocurrencia(String lugarocurrencia) {
        this.lugarocurrencia = lugarocurrencia;
    }

    public String getNombreestablecimiento() {
        return nombreestablecimiento;
    }

    public void setNombreestablecimiento(String nombreestablecimiento) {
        this.nombreestablecimiento = nombreestablecimiento;
    }

    public String getProvinciafeta() {
        return provinciafeta;
    }

    public void setProvinciafeta(String provinciafeta) {
        this.provinciafeta = provinciafeta;
    }

    public String getCantonfetal() {
        return cantonfetal;
    }

    public void setCantonfetal(String cantonfetal) {
        this.cantonfetal = cantonfetal;
    }

    public String getParroquifetal() {
        return parroquifetal;
    }

    public void setParroquifetal(String parroquifetal) {
        this.parroquifetal = parroquifetal;
    }

    public String getLocalidadfetal() {
        return localidadfetal;
    }

    public void setLocalidadfetal(String localidadfetal) {
        this.localidadfetal = localidadfetal;
    }

    public String getCausafetal() {
        return causafetal;
    }

    public void setCausafetal(String causafetal) {
        this.causafetal = causafetal;
    }
    

    public String getPrimarykey() {
        return primarykey;
    }

    public void setPrimarykey(String primarykey) {
        this.primarykey = primarykey;
    }

    public String getNombreoficina() {
        return nombreoficina;
    }

    public void setNombreoficina(String nombreoficina) {
        this.nombreoficina = nombreoficina;
    }

    public String getProvinciaoficina() {
        return provinciaoficina;
    }

    public void setProvinciaoficina(String provinciaoficina) {
        this.provinciaoficina = provinciaoficina;
    }

    public String getCantonoficina() {
        return cantonoficina;
    }

    public void setCantonoficina(String cantonoficina) {
        this.cantonoficina = cantonoficina;
    }

    public String getParroquiaoficina() {
        return parroquiaoficina;
    }

    public void setParroquiaoficina(String parroquiaoficina) {
        this.parroquiaoficina = parroquiaoficina;
    }

    public String getFechains() {
        return fechains;
    }

    public void setFechains(String fechains) {
        this.fechains = fechains;
    }

    public String getActains() {
        return actains;
    }

    public void setActains(String actains) {
        this.actains = actains;
    }


    
    
    
    
    
}
